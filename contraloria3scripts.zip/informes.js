//Script para captura de informes de auditoria


console.log("Api contraloria informes de Auditoria")

const axios = require('axios');
var fs = require('fs');
var promiseNumber = 0;

//Obtener informes desde la API
async function getInformes(comunasRegiones){

    let info = [];
    let dataResults = [];
    let contador = 0;
    for(let comunasRegion of comunasRegiones){
        for(let comuna of comunasRegion){
            let codigoComuna = comuna.CINE_COM;
            let nombreComuna = comuna.COMUNA;
            console.log("codigoComuna",codigoComuna);


            const config = {
                method: 'get',
                url: 'https://www.contraloria.cl/geoportal/api/auditoria/comunas/'+codigoComuna+'/informes',
                headers: { 'Referer': 'https://www.contraloria.cl/opencgrapp/geoportal/hallazgos' }
            }
            let res;
            
            try{
                //Sincrono para no inundar API
                res = await axios(config);
            }
            catch(err){
                console.log("error")
                res ={
                    data: []
                }
            }

            let requestInfo ={
                codigoComuna,
                nombreComuna,

            }
            info.push(requestInfo);

            dataResults.push(res.data)
            console.log("Req n",contador++);
            
            
        }
    }

    console.log("infolen",info.length);
    let jsonInfo = JSON.stringify(info);
        fs.writeFile("infoInformes.json", jsonInfo, function(err) {
            if (err) {
                console.log(err);
            }
        });

    
        console.log("infolen",dataResults.length);
    let jsonData = JSON.stringify(dataResults);
        fs.writeFile("resultsInformes.json", jsonData, function(err) {
            if (err) {
                console.log(err);
            }
        });



}

//Wrapper para llamar async
async function main(){
    let rawComunas = fs.readFileSync(`comunas.json`);

    let comunasRegiones = JSON.parse(rawComunas);

    console.log(comunasRegiones)

    console.time("getInformesT");
    await getInformes(comunasRegiones);
    console.timeEnd("getInformesT");
    //console.log(info);
}

main()