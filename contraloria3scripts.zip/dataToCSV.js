//Script para transformar datos obtenidos a CSV

console.log("Api contraloria read")

var fs = require('fs');
const converter = require('json-2-csv');

//Leer datos guardados
function read(){
    let rawInfo = fs.readFileSync(`infoInformes.json`);
    let info = JSON.parse(rawInfo);
    console.log(info.length);


    let rawInformes = fs.readFileSync(`resultsInformes.json`);
    let informes = JSON.parse(rawInformes);
    console.log(informes.length);

    let salida = { info,informes };
    console.log("salida results length", salida.informes.length);
    return salida;
}

//Transformar datos a formato requerido
function transform(info, results){
    let dataArray = []
    let contador = 0;
    for(let result of results){
        if(result.length > 0){
            let data = {};
            data.comuna = info[contador].nombreComuna;
            data.llaves = Object.keys(result[0]);
            data.obs = []    
            for(let index in result){
                data.obs.push(result[index])
            }
            dataArray.push(data)
        }
        contador++;
    }
    return dataArray;
}
//Transformar datos a CSV
function datosToCSV(datos){
    for(let dato of datos){
        let fileName = `${dato.comuna}.csv`.toLowerCase()
        converter.json2csv(dato.obs, (err, csv) => {
            if (err) {
                throw err;
            }
        
            // print CSV string
            fs.writeFile("./datos/"+fileName, csv, function(err) {
                if (err) {
                    console.log(err);
                }
            });
        });
    }
}

//Llamar procedimientos
let lectura = read();
console.log("lectura keys", Object.keys(lectura));
let info = lectura.info;
let informes = lectura.informes;
console.log("length results" , informes.length);

let datosArray = transform(info,informes);

datosToCSV(datosArray);